#!/bin/bash
cd "$(dirname "$0")"
(sleep 1; open http://localhost:3000) &
if command -v node >/dev/null 2>&1; then
  node server.js
else
  python3 -m http.server 3000
fi
