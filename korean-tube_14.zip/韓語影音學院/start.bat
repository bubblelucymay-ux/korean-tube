@echo off
cd /d "%~dp0"
if exist yt-dlp.exe (
  echo Checking subtitle tool update...
  yt-dlp.exe -U
)
where node >nul 2>nul
if %errorlevel%==0 (
  start "" /b cmd /c "timeout /t 2 /nobreak >nul && start http://localhost:3000"
  node server.js
) else (
  echo Node.js is not installed. Subtitle auto-fetch is off. Install LTS from https://nodejs.org to turn it on.
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0serve.ps1"
)
pause
