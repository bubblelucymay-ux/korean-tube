# Tiny local web server for Windows (no install needed)
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:8080/")
$listener.Start()
Start-Process "http://localhost:8080/"
Write-Host "Started: http://localhost:8080  (close this window to stop)"
while ($listener.IsListening) {
  $ctx = $listener.GetContext()
  $path = $ctx.Request.Url.AbsolutePath
  if ($path -eq "/" -or $path -eq "/index.html") {
    $bytes = [System.IO.File]::ReadAllBytes((Join-Path $root "index.html"))
    $ctx.Response.ContentType = "text/html; charset=utf-8"
    $ctx.Response.OutputStream.Write($bytes, 0, $bytes.Length)
  } else {
    $ctx.Response.StatusCode = 404
  }
  $ctx.Response.Close()
}
