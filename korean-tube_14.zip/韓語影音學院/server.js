// 韓語影音學院 - 本機小伺服器（Node 18+，不需要安裝任何套件）
// 用法：node server.js  然後開啟 http://localhost:3000
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { execFile } = require('child_process');

const PORT = process.env.PORT || 3000;
const WEB_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';
const ANDROID_UA = 'com.google.android.youtube/20.10.38 (Linux; U; Android 11) gzip';
const INNERTUBE_KEY = 'AIzaSyA8eiZmM1FaDVjRy-df2KTyQ_vz_yYM39w';

/* ---------- 取得字幕軌清單 ---------- */
// 方法一：用手機版 YouTube 的內部介面，字幕網址不需要額外驗證，最穩
async function tracksViaAndroid(id) {
  const r = await fetch(`https://www.youtube.com/youtubei/v1/player?key=${INNERTUBE_KEY}&prettyPrint=false`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'user-agent': ANDROID_UA, 'x-youtube-client-name': '3', 'x-youtube-client-version': '20.10.38' },
    body: JSON.stringify({
      context: { client: { clientName: 'ANDROID', clientVersion: '20.10.38', androidSdkVersion: 30, hl: 'en', gl: 'US' } },
      videoId: id, contentCheckOk: true, racyCheckOk: true,
    }),
  });
  const pr = await r.json();
  return readTracks(pr);
}

// 方法二：讀影片網頁裡的資料
function extractJson(html, marker) {
  const i = html.indexOf(marker);
  if (i < 0) return null;
  const start = html.indexOf('{', i);
  let depth = 0, inStr = false, esc = false;
  for (let p = start; p < html.length; p++) {
    const c = html[p];
    if (inStr) {
      if (esc) esc = false;
      else if (c === '\\') esc = true;
      else if (c === '"') inStr = false;
    } else if (c === '"') inStr = true;
    else if (c === '{') depth++;
    else if (c === '}') {
      depth--;
      if (depth === 0) return JSON.parse(html.slice(start, p + 1));
    }
  }
  return null;
}
async function tracksViaWeb(id) {
  const r = await fetch(`https://www.youtube.com/watch?v=${encodeURIComponent(id)}&hl=en`, {
    headers: { 'user-agent': WEB_UA, 'accept-language': 'en-US,en;q=0.9', cookie: 'CONSENT=YES+1; SOCS=CAI' },
  });
  const pr = extractJson(await r.text(), 'ytInitialPlayerResponse');
  if (!pr) throw new Error('讀不到影片資料');
  return readTracks(pr);
}

function readTracks(pr) {
  const title = pr.videoDetails && pr.videoDetails.title;
  const status = pr.playabilityStatus && pr.playabilityStatus.status;
  const tr = pr.captions && pr.captions.playerCaptionsTracklistRenderer;
  return { title, status, tracks: (tr && tr.captionTracks) || [] };
}

/* ---------- 解析字幕內容 ---------- */
function decode(s) {
  const one = x => x
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(+n))
    .replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCodePoint(parseInt(n, 16)))
    .replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
  return one(one(s));
}
function parseJson3(data) {
  const out = [];
  for (const ev of data.events || []) {
    if (!ev.segs) continue;
    const t = ev.segs.map(s => s.utf8 || '').join('').replace(/\n/g, ' ').trim();
    if (!t) continue;
    const s = (ev.tStartMs || 0) / 1000;
    out.push({ s, e: s + (ev.dDurationMs || 2000) / 1000, t });
  }
  return out;
}
function parseXml(x) {
  const out = [];
  let m;
  const re1 = /<text start="([\d.]+)"(?: dur="([\d.]+)")?[^>]*>([\s\S]*?)<\/text>/g;
  while ((m = re1.exec(x))) {
    const t = decode(m[3].replace(/<[^>]+>/g, '')).replace(/\s+/g, ' ').trim();
    if (t) { const s = +m[1]; out.push({ s, e: s + (+m[2] || 2), t }); }
  }
  if (out.length) return out;
  const re2 = /<p t="(\d+)"(?: d="(\d+)")?[^>]*>([\s\S]*?)<\/p>/g;
  while ((m = re2.exec(x))) {
    const t = decode(m[3].replace(/<[^>]+>/g, '')).replace(/\s+/g, ' ').trim();
    if (t) { const s = +m[1] / 1000; out.push({ s, e: s + (+m[2] || 2000) / 1000, t }); }
  }
  return out;
}

async function fetchTrack(baseUrl, tlang) {
  const url = baseUrl.replace(/&fmt=[^&]*/, '') + (tlang ? '&tlang=' + tlang : '');
  for (const fmt of ['json3', '']) {
    const r = await fetch(fmt ? `${url}&fmt=${fmt}` : url, { headers: { 'user-agent': ANDROID_UA, 'accept-language': 'en-US,en;q=0.9' } });
    const text = (await r.text()).trim();
    if (!text) continue;
    if (text.startsWith('{')) {
      try { const l = parseJson3(JSON.parse(text)); if (l.length) return l; } catch (e) { /* 試下一種 */ }
    } else {
      const l = parseXml(text);
      if (l.length) return l;
    }
  }
  throw new Error('YouTube 沒有回傳字幕內容');
}

/* ---------- 方法零：yt-dlp（資料夾裡附的 yt-dlp.exe，最穩） ---------- */
function parseVtt(txt) {
  txt = txt.replace(/\r/g, '').replace(/^WEBVTT[^\n]*\n/, '');
  const T = (h, mi, s, ms) => (+h || 0) * 3600 + (+mi) * 60 + (+s) + parseFloat('0.' + ms);
  const out = [];
  let prev = new Set();
  for (const blk of txt.split(/\n\n+/)) {
    const L = blk.split('\n');
    const i = L.findIndex(l => l.includes('-->'));
    if (i < 0) continue;
    const m = L[i].match(/(?:(\d+):)?(\d+):(\d+)[.,](\d+)\s*-->\s*(?:(\d+):)?(\d+):(\d+)[.,](\d+)/);
    if (!m) continue;
    const lines = L.slice(i + 1).map(l => decode(l.replace(/<[^>]+>/g, '')).trim()).filter(Boolean);
    const fresh = lines.filter(l => !prev.has(l)); // 自動字幕會重複上一行，只留新的
    prev = new Set(lines);
    if (!fresh.length) continue;
    out.push({ s: T(m[1], m[2], m[3], m[4]), e: T(m[5], m[6], m[7], m[8]), t: fresh.join(' ') });
  }
  return out;
}
function ytdlpBin() {
  const exe = process.platform === 'win32' ? 'yt-dlp.exe' : 'yt-dlp';
  const local = path.join(__dirname, exe);
  return fs.existsSync(local) ? local : exe;
}
const ytCache = new Map();
function runYtDlp(id) {
  if (ytCache.has(id)) return ytCache.get(id);
  const p = new Promise((resolve, reject) => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'kt-'));
    const args = ['--skip-download', '--no-playlist', '--no-warnings', '--encoding', 'utf-8',
      '--write-subs', '--write-auto-subs', '--sub-langs', 'ko.*,zh-TW,zh-Hant,zh-Hans', '--sub-format', 'vtt',
      '--print-to-file', '%(title)s', path.join(dir, 'title.txt'),
      '-o', path.join(dir, '%(id)s.%(ext)s'), `https://www.youtube.com/watch?v=${id}`];
    execFile(ytdlpBin(), args, { timeout: 120000, windowsHide: true, env: { ...process.env, PYTHONUTF8: '1' } }, (err, _o, stderr) => {
      if (err && err.code === 'ENOENT') { fs.rmSync(dir, { recursive: true, force: true }); return reject(new Error('no yt-dlp')); }
      const files = fs.readdirSync(dir).filter(f => f.endsWith('.vtt'));
      const subs = {};
      for (const f of files) {
        const lang = f.slice(id.length + 1, -4);
        try { subs[lang] = parseVtt(fs.readFileSync(path.join(dir, f), 'utf8')); } catch (e) { /* 略過壞檔 */ }
      }
      let title = '';
      try { title = fs.readFileSync(path.join(dir, 'title.txt'), 'utf8').trim(); } catch (e) { /* 沒有標題 */ }
      fs.rmSync(dir, { recursive: true, force: true });
      if (!Object.keys(subs).length) return reject(new Error('yt-dlp 沒有抓到字幕：' + String(stderr || (err && err.message) || '').trim().split('\n').slice(-2).join(' ')));
      resolve({ title, subs });
    });
  });
  ytCache.set(id, p);
  p.catch(() => ytCache.delete(id));
  setTimeout(() => ytCache.delete(id), 10 * 60 * 1000).unref();
  return p;
}
async function viaYtDlp(id, lang) {
  const { title, subs } = await runYtDlp(id);
  const keys = Object.keys(subs);
  let key;
  if (lang.startsWith('zh')) key = ['zh-TW', 'zh-Hant', 'zh-Hans'].find(k => subs[k]) || keys.find(k => k.startsWith('zh'));
  else key = keys.find(k => k.startsWith(lang.slice(0, 2)));
  if (!key || !subs[key].length) return null;
  return { title, source: 'yt-dlp', lines: subs[key] };
}

/* ---------- 選語言 ---------- */
function pickTrack(tracks, lang) {
  const hit = tracks.filter(t => (t.languageCode || '').toLowerCase().startsWith(lang.slice(0, 2)));
  if (lang.startsWith('zh')) {
    const pref = hit.find(t => /tw|hant/i.test(t.languageCode));
    if (pref) return pref;
  }
  return hit.find(t => t.kind !== 'asr') || hit[0] || null;
}
const langList = tracks => tracks.map(t => t.languageCode + (t.kind === 'asr' ? '（自動）' : '')).join('、');

async function captions(id, lang) {
  try {
    const r = await viaYtDlp(id, lang);
    if (r) return r;
  } catch (e) {
    if (e.message !== 'no yt-dlp') console.log('yt-dlp：', e.message);
  }
  let info, errs = [];
  for (const fn of [tracksViaAndroid, tracksViaWeb]) {
    try {
      const got = await fn(id);
      if (got.tracks.length) { info = got; break; }
      info = info || got;
    } catch (e) { errs.push(e.message); }
  }
  if (!info) throw new Error('連不上 YouTube：' + errs.join('；'));
  if (info.status && info.status !== 'OK') throw new Error('這支影片目前無法取得資料（' + info.status + '）');
  const { title, tracks } = info;
  if (!tracks.length) throw new Error('這支影片沒有任何 CC 字幕');

  let track = pickTrack(tracks, lang);
  let source = track ? (track.kind === 'asr' ? 'auto' : 'manual') : '';
  let lines;
  if (track) {
    lines = await fetchTrack(track.baseUrl);
  } else if (lang.startsWith('zh')) {
    // 中文：從韓文字幕請 YouTube 翻譯成繁體中文
    const base = pickTrack(tracks, 'ko');
    if (!base) throw new Error('沒有韓文字幕可以翻譯成中文');
    lines = await fetchTrack(base.baseUrl, 'zh-TW');
    source = 'translated';
  } else {
    throw new Error(`這支影片沒有「${lang === 'ko' ? '韓文' : lang}」字幕。它有的字幕語言：${langList(tracks)}。可以改用「貼上字幕」。`);
  }
  if (!lines.length) throw new Error('字幕是空的');
  return { title, source, lines };
}

/* ---------- 自動翻譯 ---------- */
async function gtx(text, sl, tl) {
  const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${sl}&tl=${tl}&dt=t&q=${encodeURIComponent(text)}`;
  const r = await fetch(url, { headers: { 'user-agent': WEB_UA } });
  if (!r.ok) throw new Error('翻譯服務回應 ' + r.status);
  const d = await r.json();
  return (d[0] || []).map(x => x[0]).join('');
}
const trCache = new Map();
async function mymemory(text, sl, tl) {
  const src = sl === 'auto' ? (/[\uAC00-\uD7AF]/.test(text) ? 'ko' : 'en') : sl;
  const r = await fetch(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=${src}|${tl}`, { headers: { 'user-agent': WEB_UA } });
  const d = await r.json();
  const t = d.responseData && d.responseData.translatedText;
  if (!t || +d.responseStatus !== 200) throw new Error('備用翻譯失敗：' + (d.responseDetails || r.status));
  return t;
}
const sleep = ms => new Promise(r => setTimeout(r, ms));
async function translateOne(text, sl, tl) {
  let err;
  for (let k = 0; k < 2; k++) {
    try { return await gtx(text, sl, tl); } catch (e) { err = e; await sleep(400 * (k + 1)); }
  }
  try { return await mymemory(text, sl, tl); } catch (e) { throw new Error(err.message + '；' + e.message); }
}
async function translateMany(texts, sl, tl) {
  const out = new Array(texts.length).fill('');
  let next = 0, fails = 0, lastErr = '';
  async function worker() {
    while (next < texts.length) {
      const i = next++;
      const key = sl + '|' + tl + '|' + texts[i];
      if (trCache.has(key)) { out[i] = trCache.get(key); continue; }
      try { out[i] = await translateOne(texts[i], sl, tl); trCache.set(key, out[i]); }
      catch (e) { fails++; lastErr = e.message; }
    }
  }
  await Promise.all(Array.from({ length: 3 }, worker));
  if (fails === texts.length && texts.length) throw new Error('翻譯失敗：' + lastErr);
  return out;
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let b = '';
    req.on('data', c => { b += c; if (b.length > 1e6) { reject(new Error('內容太大')); req.destroy(); } });
    req.on('end', () => resolve(b));
    req.on('error', reject);
  });
}

/* ---------- TOPIK 單字表（來源：amikoapp.com） ----------
   第一次啟動會在背景下載 TOPIK 1～5-6 共 100 個頁面（約 7,000 字），整理成 vocab-levels.json。
   之後啟動直接讀這個檔案，不用再連網。想重新下載：刪掉 vocab-levels.json，或用 node server.js --rebuild */
const AMIKO = 'https://amikoapp.com/zh-tw/learn-korean/vocabulary';
const AMIKO_LEVELS = [['topik-1', 1], ['topik-2', 2], ['topik-3', 3], ['topik-4', 4], ['topik-5-6', 5]];
const AMIKO_TOPICS = ['greetings', 'expressions', 'numbers-time', 'food', 'people', 'home', 'hobbies', 'shopping',
  'weather-seasons', 'directions-places', 'travel', 'work-school', 'health', 'colors-shapes', 'clothes-fashion',
  'technology', 'animals-nature', 'emergencies-safety', 'love-relationships', 'culture-traditions'];
const VOCAB_FILE = path.join(__dirname, 'vocab-levels.json');
const vocab = new Map();                       // 韓文原形 -> { lv, zh }
const vstat = { ready: false, building: false, done: 0, total: 0 };

const HANGUL = /[\uAC00-\uD7AF]/, CJK = /[\u4E00-\u9FFF]/;
// 把網頁拆成一行一行的純文字，不依賴網頁的標籤結構
function pageLines(html) {
  html = html.replace(/<(script|style|head|svg|noscript)[\s\S]*?<\/\1>/gi, '').replace(/<[^>]+>/g, '\n');
  return decode(html).split('\n').map(s => s.replace(/\s+/g, ' ').trim()).filter(Boolean);
}
// 單字列的樣子：「안녕하세요 annyeonghaseyo」→「你好」→（口語說法）→ 例句。句子和片語不收，只收單一個字。
function parseAmiko(html) {
  const L = pageLines(html), rows = [];
  for (let i = 0; i < L.length; i++) {            // 韓文和讀音若被拆成兩行，先接回來
    let s = L[i];
    if (HANGUL.test(s) && !/[A-Za-z]/.test(s) && i + 1 < L.length && /^[A-Za-z][A-Za-z' -]*$/.test(L[i + 1])) s += ' ' + L[++i];
    rows.push(s);
  }
  const out = [];
  for (let i = 0; i < rows.length; i++) {
    if (/^口[語语]/.test(rows[i]) || (i && /^口[語语]$/.test(rows[i - 1]))) continue;
    const m = rows[i].match(/^([\uAC00-\uD7AF]+)\s+[A-Za-z][A-Za-z' -]*$/);
    if (!m) continue;
    for (let j = i + 1; j <= i + 3 && j < rows.length; j++) {
      if (CJK.test(rows[j]) && !HANGUL.test(rows[j]) && !/^口[語语]/.test(rows[j])) { out.push({ ko: m[1].normalize('NFC'), zh: rows[j] }); break; }
    }
  }
  return out;
}
async function fetchPage(url) {
  for (let k = 0; k < 3; k++) {
    try {
      const r = await fetch(url, { headers: { 'user-agent': WEB_UA, 'accept-language': 'zh-TW,zh;q=0.9' } });
      if (r.ok) return await r.text();
      if (r.status === 404) return '';
    } catch (e) { /* 重試 */ }
    await sleep(600 * (k + 1));
  }
  return '';
}
async function buildVocab() {
  vstat.building = true; vstat.done = 0;
  const jobs = [];
  for (const [slug, lv] of AMIKO_LEVELS) for (const t of AMIKO_TOPICS) jobs.push({ url: `${AMIKO}/${slug}/${t}`, lv });
  vstat.total = jobs.length;
  console.log(`TOPIK 單字表：第一次使用，開始下載 ${jobs.length} 個頁面（網站可以先正常使用）…`);
  const pages = new Array(jobs.length);
  let next = 0;
  await Promise.all(Array.from({ length: 4 }, async () => {
    while (next < jobs.length) { const i = next++; pages[i] = parseAmiko(await fetchPage(jobs[i].url)); vstat.done++; }
  }));
  const perLv = {};
  jobs.forEach((j, i) => {
    for (const e of pages[i]) {
      const v = vocab.get(e.ko);
      if (!v) { vocab.set(e.ko, { lv: j.lv, zh: e.zh }); perLv[j.lv] = (perLv[j.lv] || 0) + 1; }
      else if (v.lv === j.lv) {                       // 同一級再出現：多半是同音異義字，意思併在一起
        const parts = v.zh.split('；');
        if (parts.length < 3 && !parts.includes(e.zh)) v.zh += '；' + e.zh;
      }
    }
  });
  vstat.building = false;
  if (vocab.size < 200) {
    console.log('TOPIK 單字表：只讀到 ' + vocab.size + ' 個字，不太對（可能沒連上網，或網站改版）。這次不存檔，單字會一律當成 TOPIK 3。');
    vocab.clear();
    return;
  }
  const words = {};
  for (const [k, v] of vocab) words[k] = [v.lv, v.zh];
  fs.writeFileSync(VOCAB_FILE, JSON.stringify({ built: new Date().toISOString(), words }));
  vstat.ready = true;
  console.log(`TOPIK 單字表：完成，共 ${vocab.size} 個字（` + Object.keys(perLv).map(l => `TOPIK ${l}：${perLv[l]}`).join('、') + '）');
}
function loadVocab() {
  if (!process.argv.includes('--rebuild') && fs.existsSync(VOCAB_FILE)) {
    try {
      const d = JSON.parse(fs.readFileSync(VOCAB_FILE, 'utf8'));
      for (const k of Object.keys(d.words)) vocab.set(k, { lv: d.words[k][0], zh: d.words[k][1] });
      if (vocab.size) { vstat.ready = true; console.log(`TOPIK 單字表：已讀取 ${vocab.size} 個字`); return; }
    } catch (e) { vocab.clear(); }
  }
  buildVocab().catch(e => { vstat.building = false; console.log('TOPIK 單字表錯誤：', e.message); });
}

// 字幕裡的字常常是變化形（만났어요、친구들이랑、반가워요…），試著還原成字典上的原形再查表。
// 做法：把一個字切成「詞幹＋尾巴」，尾巴要真的是助詞或詞尾才算；再把詞幹還原成字典形（含不規則變化）。
// 候選依「尾巴短的先試」排序，查表第一個命中的就是答案。
const jamo = ch => { const c = ch.charCodeAt(0) - 0xAC00; return c < 0 || c > 11171 ? null : { l: Math.floor(c / 588), v: Math.floor((c % 588) / 28), t: c % 28 }; };
const mk = (l, v, t) => String.fromCharCode(0xAC00 + (l * 21 + v) * 28 + t);
const hasFinal = ch => { const p = jamo(ch); return !!(p && p.t); };
// 助詞：C＝只接在有終聲（받침）的字後面，V＝只接在沒有終聲的字後面，R＝沒有終聲或終聲是ㄹ，空白＝不限
const PARTICLES = {
  '이': 'C', '가': 'V', '은': 'C', '는': 'V', '을': 'C', '를': 'V', '과': 'C', '와': 'V', '이랑': 'C', '랑': 'V', '으로': 'C', '로': 'R',
  '이나': 'C', '나': 'V', '이든': 'C', '든': 'V', '이라도': 'C', '라도': 'V', '이라고': 'C', '라고': 'V', '이라서': 'C', '라서': 'V',
  '이야': 'C', '야': 'V', '이에요': 'C', '예요': 'V', '이라는': 'C', '라는': 'V', '이란': 'C', '란': 'V', '이죠': 'C', '죠': 'V', '이라': 'C', '라': 'V',
  '으로서': 'C', '로서': 'R', '으로써': 'C', '로써': 'R', '이다': 'C', '이니까': 'C', '니까': 'V', '이지만': 'C', '지만': 'V',
  '에서': '', '에게서': '', '에게': '', '한테서': '', '한테': '', '께서': '', '께': '', '에': '', '도': '', '만': '', '의': '', '하고': '', '까지': '',
  '부터': '', '보다': '', '처럼': '', '마다': '', '밖에': '', '조차': '', '마저': '', '뿐': '', '만큼': '', '같이': '', '들': '', '요': '', '입니다': '', '에다': '', '에다가': '',
};
const PART_LIST = Object.keys(PARTICLES).sort((a, b) => b.length - a.length);
const agrees = (prev, part) => {
  const rule = PARTICLES[part], p = jamo(prev);
  if (!rule || !p) return true;
  if (rule === 'C') return p.t !== 0;
  if (rule === 'V') return p.t === 0;
  if (rule === 'R') return p.t === 0 || p.t === 8;
  return true;
};
// 尾巴是不是一串助詞（들이랑、에서는、으로도…），並且每個助詞都接得上前一個字
function isParticleChain(prev, rest) {
  if (!rest) return true;
  for (const part of PART_LIST) {
    if (rest.startsWith(part) && agrees(prev, part) && isParticleChain(part[part.length - 1], rest.slice(part.length))) return true;
  }
  return false;
}
const PRE = ['으시', '시', '셨', '으셨', '었', '았', '였', '겠'];
const ENDS = ('요 어요 아요 여요 세요 으세요 셔요 어 아 여 서 어서 아서 여서 니까 으니까 니 으니 면 으면 지 지요 지만 고 도 도록 게 게요 네 네요 군 군요 구나 자 잖아 잖아요 ' +
  '는 은 을 던 는데 은데 을까 까 까요 을까요 래 래요 을래 을게 을게요 려고 으려고 러 으러 며 으며 다 다가 다고 다는 라 라고 라는 냐 습니다 니다 십시오 십니다 ' +
  '에요 예요 이에요 이야 야 죠 지마 어도 아도 여도 어야 아야 여야 든지 든 다면 는지 은지 을지 는군 는구나 는다 ㅂ니다').split(' ').filter(x => x && !/[ㄱ-ㅎ]/.test(x));
const END_LIST = ENDS.sort((a, b) => b.length - a.length);
const VERB_TAIL = new RegExp('^(?:' + PRE.join('|') + ')*(?:' + END_LIST.join('|') + ')$');
const L_ENDING = /^(래|게|까|께)/;        // 갈래、갈게、갈까：ㄹ 是尾巴的一部分，優先還原成「가다」
const PRON = { '내': '나', '제': '저', '네': '너', '난': '나', '넌': '너' };
const VOWEL_BACK = { 9: 8, 14: 13, 6: 20 };       // 와→오　워→우　여→이（봐→보、줘→주、마셔→마시）

// 詞幹 → 字典形（含不規則變化）。回傳依可能性排序的候選。
function stemBases(s, preferOpen) {
  const out = [], add = x => { if (x && !out.includes(x)) out.push(x); };
  const ch = [...s], last = ch[ch.length - 1], pl = jamo(last);
  if (!pl) { add(s + '다'); return out; }
  const head = ch.slice(0, -1).join('');
  const forms = [];
  const open = [4, 8, 16, 17, 20].includes(pl.t) ? head + mk(pl.l, pl.v, 0) : null;   // 갔→가、할→하、간→가、합→하、함→하
  if (open && preferOpen) forms.push(open);
  forms.push(s);
  if (open && !preferOpen) forms.push(open);
  for (const f of forms) {
    const fc = [...f], fl = fc[fc.length - 1], fh = fc.slice(0, -1).join(''), p = jamo(fl);
    if (!p) continue;
    const prev = fc.length > 1 ? jamo(fc[fc.length - 2]) : null, ph = fc.slice(0, -2).join('');
    // 하다 動詞：해、했、하、할…→ X하다（字典沒有 X하다 時退而求其次用名詞 X）
    if (p.l === 18 && (p.v === 1 || p.v === 0) && p.t === 0) { add(fh + '하다'); add(fh); }
    add(f + '다');
    if (p.t === 0 && VOWEL_BACK[p.v] !== undefined) add(fh + mk(p.l, VOWEL_BACK[p.v], 0) + '다');           // 봐→보다、마셔→마시다
    // ㅂ 불규칙：반가워→반갑다、도와→돕다、아름다운→아름답다
    if (prev && prev.t === 0) {
      if (p.t === 0 && p.l === 11 && (p.v === 14 || p.v === 9)) add(ph + mk(prev.l, prev.v, 17) + '다');
      if (p.l === 11 && p.v === 13 && (p.t === 4 || p.t === 8 || p.t === 0)) add(ph + mk(prev.l, prev.v, 17) + '다');
    }
    // 르 불규칙：몰라→모르다、달라→다르다
    if (prev && prev.t === 8 && p.l === 5 && p.t === 0 && (p.v === 0 || p.v === 4)) add(ph + mk(prev.l, prev.v, 0) + '르다');
    // ㅎ 불규칙：그래→그렇다、어때→어떻다、그런→그렇다
    if (p.v === 1 && p.t === 0 && p.l !== 18) add(fh + mk(p.l, 4, 27) + '다');
    if (p.v === 4 && p.t === 4) add(fh + mk(p.l, 4, 27) + '다');
    // ㅡ 탈락：아파→아프다、써→쓰다、예뻐→예쁘다、커→크다
    if (p.t === 0 && (p.v === 0 || p.v === 4)) add(fh + mk(p.l, 18, 0) + '다');
    // 되다：돼→되다
    if (p.v === 10 && p.t === 0) add(fh + mk(p.l, 11, 0) + '다');
    // ㄹ 탈락：아는→알다、사는→살다、만드는→만들다
    if (p.t === 0) add(fh + mk(p.l, p.v, 8) + '다');
  }
  return out;
}
const AMBIG_1 = new Set(['이', '가', '야', '라', '요', '죠', '나', '다']);   // 單音節的詞幹＋單音節尾巴，太容易是一個完整的字（나라、하나、아이）
function candidates(w) {
  const out = [], add = x => { if (x && !out.includes(x)) out.push(x); };
  const ch = [...w];
  add(w);
  for (let cut = 0; cut <= Math.min(6, ch.length - 1); cut++) {
    const keep = ch.length - cut, tail = ch.slice(keep).join(''), stem = ch.slice(0, keep).join('');
    const chain = cut > 0 && isParticleChain(ch[keep - 1], tail);
    if (chain && keep === 1 && PRON[stem]) add(PRON[stem]);            // 내가→나、제가→저、네가→너
    const nounOk = chain && !(keep === 1 && AMBIG_1.has(tail));
    const verbOk = cut === 0 || VERB_TAIL.test(tail);
    if (!nounOk && !verbOk) continue;
    if (nounOk) add(stem);
    if (verbOk) stemBases(stem, L_ENDING.test(tail) || cut === 0).forEach(add);
  }
  return out;
}
// 自訂字典 custom-vocab.json：表裡沒有、或翻錯的字，可以自己補，優先於 TOPIK 單字表。存檔後不用重開伺服器。
// 格式：{ "성인식": { "zh": "成年禮", "lv": 3 } }   （lv 不寫就是 3）
const CUSTOM_FILE = path.join(__dirname, 'custom-vocab.json');
let custom = new Map(), customStamp = -1;
function loadCustom() {
  try {
    const st = fs.statSync(CUSTOM_FILE);
    if (st.mtimeMs === customStamp) return;
    customStamp = st.mtimeMs;
    const d = JSON.parse(fs.readFileSync(CUSTOM_FILE, 'utf8')), m = new Map();
    for (const k of Object.keys(d)) if (d[k] && d[k].zh) m.set(k.normalize('NFC'), { lv: Math.min(6, Math.max(1, +d[k].lv || 3)), zh: String(d[k].zh) });
    custom = m;
  } catch (e) { if (customStamp !== -1 || custom.size) { custom = new Map(); customStamp = -1; } }
}
function lookupWord(raw) {
  loadCustom();
  const w = String(raw).replace(/[^\uAC00-\uD7AF]/g, '').normalize('NFC');
  if (!w) return { hit: false };
  for (const c of candidates(w)) {
    const v = custom.get(c) || vocab.get(c);
    if (v) return { hit: true, base: c, lv: v.lv, zh: v.zh };
  }
  return { hit: false };
}

/* ---------- 影片下載到本機（離線可看） ----------
   用資料夾裡的 yt-dlp 把影片存進 videos/ 資料夾（單一 MP4 檔，最高 720p，不需要 ffmpeg），再由本機網站播放。 */
const VIDEO_DIR = path.join(__dirname, 'videos');
const VIDEO_EXT = { '.mp4': 'video/mp4', '.webm': 'video/webm', '.mkv': 'video/x-matroska', '.m4v': 'video/mp4' };
const dls = new Map();                                 // id -> { state:'running'|'error', pct, error }
function videoFile(id) {
  try {
    const f = fs.readdirSync(VIDEO_DIR).find(n => n.startsWith(id + '.') && VIDEO_EXT[path.extname(n).toLowerCase()] && !n.endsWith('.part'));
    return f ? { file: f, size: fs.statSync(path.join(VIDEO_DIR, f)).size } : null;
  } catch (e) { return null; }
}
function dlStatus(id) {
  const f = videoFile(id), d = dls.get(id);
  if (d && d.state === 'running') return { state: 'running', pct: d.pct, msg: d.msg || '' };
  if (f) return { state: 'done', file: f.file, size: f.size };
  if (d && d.state === 'error') return { state: 'error', error: d.error };
  return { state: 'none' };
}
function ffmpegPath() {
  const local = path.join(__dirname, process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg');
  if (fs.existsSync(local)) return local;
  try { require('child_process').execFileSync('ffmpeg', ['-version'], { stdio: 'ignore', windowsHide: true }); return 'ffmpeg'; } catch (e) { return ''; }
}
// Windows 沒有 ffmpeg 時，第一次需要才自動下載（約 30 MB，只下載一次，存在資料夾裡）
const FFMPEG_URL = 'https://github.com/eugeneware/ffmpeg-static/releases/download/b6.1.1/ffmpeg-win32-x64.gz';
let ffGet = null;
function ensureFfmpeg() {
  if (ffGet) return ffGet;
  ffGet = (async () => {
    const r = await fetch(FFMPEG_URL);
    if (!r.ok) throw new Error('下載 ffmpeg 失敗（' + r.status + '）');
    const gz = Buffer.from(await r.arrayBuffer());
    const exe = require('zlib').gunzipSync(gz);
    const dest = path.join(__dirname, 'ffmpeg.exe');
    fs.writeFileSync(dest + '.tmp', exe); fs.renameSync(dest + '.tmp', dest);
    return dest;
  })();
  ffGet.catch(() => { ffGet = null; });
  return ffGet;
}
function startDownload(id) {
  const cur = dls.get(id);
  if (cur && cur.state === 'running') return;
  if (videoFile(id)) return;
  fs.mkdirSync(VIDEO_DIR, { recursive: true });
  const d = { state: 'running', pct: 0, error: '' };
  dls.set(id, d);
  const { spawn } = require('child_process');
  let ff = ffmpegPath();
  // 先試「影像＋聲音在同一個檔」的格式（不用 ffmpeg）；YouTube 沒有這種格式時，有 ffmpeg 就改成分開下載再合併成 MP4
  const attempts = [{ f: 'b[ext=mp4][height<=720]/b[height<=720]/b', merge: false }];
  if (ff) attempts.push({ f: 'bv*[height<=720]+ba/b[height<=720]/bv*+ba/b', merge: true });
  let tail = '', n = 0;
  const run = () => {
    const at = attempts[n];
    const args = ['--no-playlist', '--no-warnings', '--newline', '--encoding', 'utf-8', '-f', at.f,
      ...(at.merge ? ['--merge-output-format', 'mp4', '--ffmpeg-location', ff] : []),
      '-o', path.join(VIDEO_DIR, '%(id)s.%(ext)s'), `https://www.youtube.com/watch?v=${id}`];
    let child;
    try { child = spawn(ytdlpBin(), args, { windowsHide: true, env: { ...process.env, PYTHONUTF8: '1' } }); }
    catch (e) { d.state = 'error'; d.error = String(e.message); return; }
    d.pct = 0;
    const onData = b => {
      const t = b.toString(); tail = (tail + t).slice(-800);
      for (const m of t.matchAll(/(\d+(?:\.\d+)?)%/g)) d.pct = Math.max(d.pct, Math.min(99, +m[1]));
    };
    child.stdout.on('data', onData); child.stderr.on('data', onData);
    child.on('error', e => { d.state = 'error'; d.error = e.code === 'ENOENT' ? '找不到 yt-dlp（Windows 請確認資料夾裡有 yt-dlp.exe；Mac 請先安裝 yt-dlp）' : String(e.message); });
    child.on('close', code => {
      if (d.state === 'error') return;
      if (code === 0 && videoFile(id)) { dls.delete(id); return; }
      if (++n < attempts.length) { run(); return; }
      if (/format is not available/i.test(tail) && !ff && process.platform === 'win32') {
        d.msg = '這支影片需要 ffmpeg，第一次使用自動下載中（約 30 MB，只會下載一次）…';
        ensureFfmpeg().then(p => { ff = p; d.msg = ''; attempts.push({ f: 'bv*[height<=720]+ba/b[height<=720]/bv*+ba/b', merge: true }); run(); })
          .catch(e => { d.state = 'error'; d.error = '自動下載 ffmpeg 失敗（' + e.message + '）。請連上網路後再按一次，或手動把 ffmpeg.exe 放進這個資料夾。'; });
        return;
      }
      d.state = 'error';
      if (/format is not available/i.test(tail) && !ff)
        d.error = '這支影片 YouTube 只提供「影像」和「聲音」分開的格式，需要 ffmpeg 才能合併。請手動把 ffmpeg.exe 放進這個資料夾；Mac 請輸入 brew install ffmpeg 安裝。';
      else d.error = '下載失敗：' + (tail.trim().split('\n').slice(-2).join(' ') || '代碼 ' + code);
    });
  };
  run();
}
function serveVideo(req, res, name) {
  const file = path.join(VIDEO_DIR, path.basename(name));
  const type = VIDEO_EXT[path.extname(file).toLowerCase()];
  if (!type || !fs.existsSync(file)) { res.statusCode = 404; return res.end('Not found'); }
  const size = fs.statSync(file).size, range = req.headers.range;
  res.setHeader('content-type', type); res.setHeader('accept-ranges', 'bytes');
  if (range) {
    const m = /bytes=(\d*)-(\d*)/.exec(range);
    let start = m && m[1] ? +m[1] : 0, end = m && m[2] ? +m[2] : size - 1;
    if (m && !m[1] && m[2]) { start = Math.max(0, size - +m[2]); end = size - 1; }
    if (start >= size || end < start) { res.statusCode = 416; res.setHeader('content-range', `bytes */${size}`); return res.end(); }
    end = Math.min(end, size - 1);
    res.statusCode = 206; res.setHeader('content-range', `bytes ${start}-${end}/${size}`); res.setHeader('content-length', end - start + 1);
    fs.createReadStream(file, { start, end }).on('error', () => res.destroy()).pipe(res);
  } else {
    res.setHeader('content-length', size);
    fs.createReadStream(file).on('error', () => res.destroy()).pipe(res);
  }
}

/* ---------- 網站 ---------- */
const server = http.createServer(async (req, res) => {
  const u0 = new URL(req.url, 'http://localhost');
  if (u0.pathname === '/api/lookup') {
    res.setHeader('content-type', 'application/json; charset=utf-8');
    try {
      let words = u0.searchParams.getAll('w');
      if (req.method === 'POST') words = JSON.parse(await readBody(req)).words || [];
      words = words.slice(0, 300).map(w => String(w).slice(0, 60));
      res.end(JSON.stringify({ ready: vstat.ready, size: vocab.size, building: vstat.building, progress: vstat.total ? vstat.done + '/' + vstat.total : '', results: words.map(lookupWord) }));
    } catch (e) {
      res.statusCode = 502;
      res.end(JSON.stringify({ error: String(e.message || e) }));
    }
    return;
  }
  const u = new URL(req.url, 'http://localhost');
  if (u.pathname === '/api/captions') {
    res.setHeader('content-type', 'application/json; charset=utf-8');
    try {
      const id = (u.searchParams.get('v') || '').replace(/[^\w-]/g, '');
      const lang = (u.searchParams.get('lang') || 'ko').toLowerCase();
      if (!id) throw new Error('缺少影片 ID');
      res.end(JSON.stringify(await captions(id, lang)));
    } catch (e) {
      console.log('字幕錯誤：', e.message);
      res.statusCode = 502;
      res.end(JSON.stringify({ error: String(e.message || e) }));
    }
    return;
  }
  if (u.pathname === '/api/translate' && req.method === 'POST') {
    res.setHeader('content-type', 'application/json; charset=utf-8');
    try {
      const body = JSON.parse(await readBody(req));
      const texts = (body.texts || []).slice(0, 100).map(t => String(t).slice(0, 500));
      const sl = /^[a-z-]+$/i.test(body.sl || '') ? body.sl : 'auto';
      const tl = /^[a-z-]+$/i.test(body.tl || '') ? body.tl : 'zh-TW';
      res.end(JSON.stringify({ translations: await translateMany(texts, sl, tl) }));
    } catch (e) {
      console.log('翻譯錯誤：', e.message);
      res.statusCode = 502;
      res.end(JSON.stringify({ error: String(e.message || e) }));
    }
    return;
  }
  if (u.pathname.startsWith('/videos/')) { serveVideo(req, res, decodeURIComponent(u.pathname.slice(8))); return; }
  if (u.pathname.startsWith('/api/dl-')) {
    res.setHeader('content-type', 'application/json; charset=utf-8');
    const id = (u.searchParams.get('v') || '').replace(/[^\w-]/g, '');
    if (u.pathname === '/api/dl-list') {
      const out = {};
      try { for (const n of fs.readdirSync(VIDEO_DIR)) { const e = path.extname(n).toLowerCase(); if (VIDEO_EXT[e]) { const sid = n.slice(0, -e.length); const st = dlStatus(sid); if (st.state === 'done') out[sid] = st.size; } } } catch (e) { /* 還沒有 videos 資料夾 */ }
      res.end(JSON.stringify({ videos: out })); return;
    }
    if (!/^[\w-]{11}$/.test(id)) { res.statusCode = 400; res.end(JSON.stringify({ error: '影片 ID 不對' })); return; }
    if (u.pathname === '/api/dl-start' && req.method === 'POST') startDownload(id);
    if (u.pathname === '/api/dl-delete' && req.method === 'POST') {
      const f = videoFile(id); if (f && !(dls.get(id) || {}).state) fs.rmSync(path.join(VIDEO_DIR, f.file), { force: true });
      dls.delete(id);
    }
    res.end(JSON.stringify(dlStatus(id))); return;
  }
  if (u.pathname === '/' || u.pathname === '/index.html') {
    res.setHeader('content-type', 'text/html; charset=utf-8');
    res.setHeader('cache-control', 'no-store');
    res.end(fs.readFileSync(path.join(__dirname, 'index.html')));
    return;
  }
  res.statusCode = 404;
  res.end('Not found');
});

if (require.main === module) {
  server.listen(PORT, () => { console.log(`韓語影音學院 v14 已啟動： http://localhost:${PORT}（資料夾：${__dirname}）`); loadVocab(); });
} else {
  module.exports = { parseAmiko, lookupWord, candidates, vocab, server, loadVocab };
}
